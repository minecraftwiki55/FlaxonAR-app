package com.flaxon.app;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.content.Intent;
import android.view.View;
import android.widget.TextView;

public class CreateAccountActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.create_account);

        Spinner countrySpinner2 = findViewById(R.id.country_spinner2);

        String[] countries = {
            "🇸🇦 السعودية", 
            "🇦🇪 الإمارات", 
            "🇪🇬 مصر", 
            "🇯🇴 الأردن", 
            "🇶🇦 قطر", 
            "🇧🇭 البحرين", 
            "🇰🇼 الكويت", 
            "🇴🇲 عمان", 
            "🇱🇧 لبنان", 
            "🇸🇾 سوريا", 
            "🇮🇶 العراق", 
            "🇲🇦 المغرب", 
            "🇩🇿 الجزائر", 
            "🇹🇳 تونس", 
            "🇱🇾 ليبيا", 
            "🇸🇩 السودان", 
            "🇾🇪 اليمن", 
            "🇲🇷 موريتانيا", 
            "🇸🇴 الصومال", 
            "🇰🇲 جزر القمر", 
            "🇩🇯 جيبوتي", 
            "❤🇵🇸 فلسطين"
        };

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, countries);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        countrySpinner2.setAdapter(adapter);

        TextView signupText2 = findViewById(R.id.signup_text2);
        signupText2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(CreateAccountActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}