package com.flaxon.pe.app;



import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
		if (getSupportActionBar() != null) {
       getSupportActionBar().hide();
       }
        setContentView(R.layout.activity_main);

        Spinner countrySpinner = findViewById(R.id.country_spinner);

        String[] countries = {
            "🇸🇦 السعودية", 
            "🇦🇪 الإمارات", 
            "🇪🇬 مصر", 
            "🇯🇴 الأردن", 
            "🇶🇦 قطر", 
            "🇧🇭 البحرين", 
            "🇰🇼 الكويت", 
            "🇴🇲 عمان", 
            "🇱🇧 لبنان", 
            "🇸🇾 سوريا", 
            "🇮🇶 العراق", 
            "🇲🇦 المغرب", 
            "🇩🇿 الجزائر", 
            "🇹🇳 تونس", 
            "🇱🇾 ليبيا", 
            "🇸🇩 السودان", 
            "🇾🇪 اليمن", 
            "🇲🇷 موريتانيا", 
            "🇸🇴 الصومال", 
            "🇰🇲 جزر القمر", 
            "🇩🇯 جيبوتي", 
            "❤🇵🇸 فلسطين"
        };

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, countries);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        countrySpinner.setAdapter(adapter);
    }
}